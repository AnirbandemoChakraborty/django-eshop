from django import template

register = template.Library()


@register.filter(name='is_in_cart')

def is_in_cart(product_id,cart):
    keys = cart.keys()
    for prod_cart in keys:
        if (prod_cart != "null") and (product_id != "null"):
            if int(product_id) == int(prod_cart):
                return True
    return False


@register.filter(name='cart_product_id_quant')

def cart_product_id_quant(product_id,cart):
    keys = cart.keys()
    for prod_cart in keys:
        if (prod_cart != "null") and (product_id != "null"):
            if int(product_id) == int(prod_cart):
                return cart.get(prod_cart)
        else:
            print("This product is null")
    return 0

@register.filter(name = 'get_total_price_per_product_name')
def get_total_price_per_product_name(product,cart):
    return (product.price *  cart_product_id_quant(product.id,cart))


@register.filter(name='get_total_price_for_checkout')
def get_total_price_for_checkout(products,cart):
    sum=0
    for product in products:
        sum += (product.price *  cart_product_id_quant(product.id,cart))
    return sum



@register.filter(name='multiply')
def multiply(num1,num2):
    return num1 * num2

   

