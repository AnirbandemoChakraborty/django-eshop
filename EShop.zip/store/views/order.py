from django.views import View
from django.shortcuts import render, redirect
from store.models import Customer
from django.contrib.auth.hashers import check_password
from store.models.product import Product
from store.models.order import Order
from store.middleware.auth import auth_middleware


class OrderView(View):
    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Order.get_orders_by_customer_id(customer)
        return render(request,'order.html' ,{'orders' : orders})
