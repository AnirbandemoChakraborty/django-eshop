from django.views import View
from django.shortcuts import render, redirect,HttpResponseRedirect
from store.models import Customer
from django.contrib.auth.hashers import check_password


class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        print("My URL is",Login.return_url )
        return render(request, 'login.html')
    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer  = Customer.getcustomerbyemail(email)
        error_collector = {}
        data = {}
        data['email'] = email
        if customer:
            if check_password(password, customer.password):
                request.session['customer_id'] = customer.id
                request.session['customer_email'] = customer.email
                print("Test this", Login.return_url)
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    return redirect('index')
            else:
                data['email_error'] = "Your login id or password is wrong"
                return render(request, 'login.html',data )
            
        else:
            data['email_error'] = "Your login id or password is wrong"
            return render(request, 'login.html',data )
def logout(request):
    request.session.clear()
    return redirect('login')
