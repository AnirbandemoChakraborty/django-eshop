from django.views import View
from django.shortcuts import render, redirect
from store.models import Customer
from django.contrib.auth.hashers import check_password
from store.models.product import Product
from store.models.order import Order


class CheckOut(View):
    def post(self, request):
        phone = request.POST.get('Phone')
        address =  request.POST.get('Address')
        customer = request.session.get('customer_id')
        email = request.session.get('customer_email')
        cart = request.session.get('cart')
        products = Product.get_product_by_product_id(list(cart.keys()))
        for product in products:
            print(product)
            order = Order(product=product,
            customer = customer,
            price = product.price,
            address=address,
            phone=phone,
            email=email,
            quantity=int(cart.get(str(product.id))))
            order.place_order()
        request.session['cart'] = {}
        return redirect('cart')

 