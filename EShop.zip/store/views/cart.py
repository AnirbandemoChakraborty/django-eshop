from django.views import View
from django.shortcuts import render, redirect
from store.models import Customer
from django.contrib.auth.hashers import check_password
from store.models.product import Product


class Cart(View):
    def get(self, request):
        if request.session.get('cart'):
            ids = list(request.session.get('cart').keys())
            product_details = Product.get_product_by_product_id(ids)
            return render(request, 'cart.html' , {'products' : product_details})
        else:
            return render(request, 'cart.html' )
 