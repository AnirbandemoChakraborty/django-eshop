from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View

class SignUp(View):
    def get(self, request):
        return render(request,'signup.html')
    
    def post(self, request):
        return self.registeruser(request)

    def signup_form_validation(customer):
        error_message = {}
        if (not customer.first_name):
            error_message['first_nameerr'] = "First Name is required"
        elif (len(customer.first_name) < 4):
            error_message['first_nameerr'] = "First Name should be atleast of 4 characters"

        if (not customer.last_name):
            error_message['last_nameerr'] = "Last Name is required"
        elif (len(customer.last_name) < 4):
            error_message['last_nameerr']  = "Last Name should be atleast of 4 characters"

        if (not customer.password):
            error_message['passworderr'] = "Password is required"
        elif (len(customer.password) < 6):
            error_message['passworderr'] = "Password should be atleast of 6 characters"

        if (not customer.phone):
            error_message['phoneerr'] = "phone number is required"
        elif (len(customer.phone) < 10):
            error_message['phoneerr'] = "phone number be atleast of 10 characters"
        
        email_unique = customer.ifemailexist()
        if email_unique:
            error_message['emailerr'] = "This email is already registered. Use a different email or login with the same email"
        return error_message


    def registeruser(self, request):
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        phone = request.POST.get('phonenumber')
        email = request.POST.get('email')
        password = request.POST.get('password')
        #Form Validation
        customer = Customer(first_name = first_name,last_name = last_name, phone=phone,email=email,password=password)
        value = {}
        value = {
            'first_name' : first_name,
            'last_name' : last_name,
            'phone' : phone,
            'email': email,
        }
        data = {
            'error' : SignUp.signup_form_validation(customer),
            'value' : value
        }
        print(data)
        if (not SignUp.signup_form_validation(customer)):
            print("there is no error")
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('index')
        else:
            print("There is an error")
            return render(request,'signup.html', data)