from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class Index(View):
    def get(self,request):
        product = None  
        category = Category.get_all_categories()

        category_id  = request.GET.get('category')
        if category_id:
            product = Product.get_all_products_by_category_id(category_id)
            if product:
                product = product  
            else:
                product = {}
                product['name'] = "No item found for your filter"
        else:
            product = Product.get_all_products()
        
        print(product)


        data = {}
        data['products'] = product
        data['categories'] = category
        #return render(request, 'orders/orders.html')
        print(request.session.get('customer_email'))
        return render(request, 'index.html', data)



    def post(self,request):
        product_id  = request.POST.get('product_id_add_to_cart')
        print(product_id)
        cart = request.session.get('cart')
        remove = request.POST.get('remove')
        print("this is cart:" , cart)
        if cart:
            quantity = cart.get(product_id)
            print(quantity)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product_id)
                    else:
                        cart[product_id] = quantity-1
                else:
                    cart[product_id] = quantity+1
            else:
                cart[product_id] = 1       
        else:
            cart = {}
            cart[product_id] = 1
        request.session['cart'] = cart
        print(request.session['cart'])
        return redirect('index')
    