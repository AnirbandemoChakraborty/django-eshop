from django.db import models
from .customer import Customer
from .product import Product
import datetime


class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    customer = models.CharField(max_length=500,blank=True,null=True)
    quantity = models.IntegerField()
    price = models.IntegerField()
    date = models.DateField(default=datetime.datetime.today)
    address = models.CharField(max_length = 500, default=1)
    phone = models.CharField(max_length = 12, default=1)
    email = models.CharField(max_length=500, default=1)
    status = models.BooleanField(default=False)
        
    def place_order(self):
        self.save()
    
    def get_orders_by_customer_id(customer_id):
        return (Order.objects.filter(customer=customer_id).order_by('-date'))