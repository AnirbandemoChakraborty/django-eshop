from django.urls import path
from .views import login, signup, index, cart,checkout,order
from .middleware.auth  import auth_middleware


urlpatterns = [
    path('', index.Index.as_view(), name='index'),
    path('/home', index.Index.as_view(), name='index'),
    #path('signup', views.SignUp.as_view() , name='signup'),
    #path('login', views.Login.as_view() , name='login')
    path('login', login.Login.as_view() , name='login'),
    path('signup', signup.SignUp.as_view() , name='signup'),
    path('logout', login.logout , name='logout'),
    path('cart', cart.Cart.as_view() , name='cart'),
    path('check-out', checkout.CheckOut.as_view() , name='check-out'),
    path('order', auth_middleware(order.OrderView.as_view()) , name='order'),
]
