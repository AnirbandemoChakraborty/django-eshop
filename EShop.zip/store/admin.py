from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.order import Order


class AdminModelProduct(admin.ModelAdmin):
    list_display = ['name','price','category']
class AdminModelCategory(admin.ModelAdmin):
    list_display = ['name']
class AdminModelCustomer(admin.ModelAdmin):
    list_display = ['first_name','last_name','email','phone']
# Register your models here.


class adminViewOrder(admin.ModelAdmin):
    list_display = ['customer', 'product','quantity','price' ,'date','status']

admin.site.register(Product,AdminModelProduct )
admin.site.register(Category,AdminModelCategory)
admin.site.register(Customer,AdminModelCustomer)
admin.site.register(Order, adminViewOrder)
